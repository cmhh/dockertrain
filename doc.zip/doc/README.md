A basic slide deck written with [reveal.js](https://revealjs.com).
